#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

//Aidan Steen, 22May24

void printMenu() { //Menu that will be displayed to the user one they enter the while loop.
	cout << endl;
	cout << "**********************" << endl;
	cout << "* 1 - Add One Hour   *" << endl;
	cout << "* 2 - Add One Minute *" << endl;
	cout << "* 3 - Add One Second *" << endl;
	cout << "* 4 - Exit Program   *" << endl;
	cout << "**********************" << endl;
	cout << endl;
}

void printClocks(int& hour, int& minute, int& second) {
	int hourTwelve;
	string amPm = "AM";


	if (hour == 0) {
		hourTwelve = 12;
	}
	else if (hour == 12) {
		hourTwelve = hour;
		amPm = "PM"; //Switches from AM to PM
	}
	else if (hour > 12) {
		hourTwelve = hour - 12; // formats 12-hour clock
		amPm = "PM"; //Switches from AM to PM
	}
	else {
		hourTwelve = hour;
	}
	//Format for the clocks
	cout << "\t\t*************************\t*************************" << endl;
	cout << "\t\t*     " << "12-Hour Clock";
	cout << "\t*";
	cout << "\t*" << "     24-Hour Clock";
	cout << "\t*" << endl;
	//12-hour clock
	cout << "\t\t*      ";
	cout << setw(2) << setfill('0') << hourTwelve << ":";    // formatted 12-hour
	cout << setw(2) << minute << ":";
	cout << setw(2) << second << amPm;
	cout << "\t*";
	//24-hour clock
	cout << "\t*\t";
	cout << setw(2) << setfill('0') << hour << ":";
	cout << setw(2) << minute << ":";
	cout << setw(2) << second;
	cout << "\t*" << endl;
	cout << "\t\t*************************\t*************************" << endl;
}

void updateClock(int& input, int& hour, int& minute, int& second) { //Uses the user input to either add an hour, minute, or second.
	if (input == 1) {
		if (hour < 23) { //If it becomes greater than 23, it resets the hour to 00.
			++hour;
		}
		else {
			hour = 00;
		}
	}
	else if (input == 2) { //If it becomes greater than 59, it resets the minute to 00 and adds one to the hour counter.
		if (minute < 59) {
			++minute;
		}
		else {
			minute = 00;
			hour++;
		}
	}
	else if (input == 3) { // If it becomes greater than 59, it resets the second to 00 and adds one to the minute counter.
		if (second < 59) {
			++second;
		}
		else {
			minute++;
			second = 00;
		}
		if (minute == 60) { // If adding the second increases the minute counter and then the minute counter hits 60, it adds an hour and resets the minutes to 00.
			hour++;
			minute = 00;
		}
		if (hour == 24) { // If because adding a second makes the hour 24, it resets it to 00.
			hour = 00;
		}

	}
	else if (input == 4) {
		cout << "Goodbye!";
	}
}

void initialTimeSet(bool validInput, int& hour, int& minute, int& second) { // Makes sure that the input being fed by the user is valid. 
	//If it is invalid, prompts the user to retype an input.
	while (validInput == false) {
		cout << "Please enter the hour." << endl;
		cin >> hour;
		while (hour > 23 || hour < 0) {
			validInput = false;
			cout << "Invalid" << endl;
			cin >> hour;
		}
		cout << "Please enter the minute." << endl;
		cin >> minute;
		while (minute > 59 || minute < 0) {
			validInput = false;
			cout << "Invalid" << endl;
			cin >> minute;
		}
		cout << "Please enter the second." << endl;
		cin >> second;
		while (second > 59 || second < 0) {
			validInput = false;
			cout << "Invalid" << endl;
			cin >> second;
		}
		validInput = true;
	}
}
void invalidInput(int& input) {
	cin >> input;
	if (input != 1 && input != 2 && input != 3 && input != 4) { //If statement catches inputs that are > 5 and less than 0. Prompts user to choose from menu.
		cout << "Invalid input. Please select a number from the menu." << endl;
		cout << endl;
	}
}

int main() {

	int input = 0;
	int hour = 0;
	int minute = 0;
	int second = 0;
	bool validInput = false;

	initialTimeSet(validInput, hour, minute, second);
	
	while (input != 4) {
		printClocks(hour, minute, second);
		printMenu();
		invalidInput(input);
		updateClock(input, hour, minute, second);
	}
	return 0;
}