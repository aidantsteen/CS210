#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

//Aidan Steen
//CS-210
//05/25/2024

int main() {
	ifstream inFS;//opens input file
	ofstream outFS;//creates output file
	string city;
	double temperature;
	double celcius;

	inFS.open("FahrenheitTemperature.txt");//opens input file
	outFS.open("CelciusTemperature.txt");//opens output file

	if (!inFS.is_open()) { //checks if input file is open
		std::cout << "Could not open file FahrenheitTemperature.txt." << endl;
		return 1;
	}
	if (!outFS.is_open()) { //checks if output file is open
		std::cout << "Could not open file CelciusTemperature.txt." << endl;
	}

	while (!inFS.eof()) {//reads file until the contents are read completely.
		inFS >> city;
		inFS >> temperature;
		celcius = (temperature - 32) * 5 / 9;//converts fahrenheit to celcius
		std::cout << city << " " << temperature << endl;// reads contents of file with formatting.
		outFS << city << " " << setprecision(3) << celcius << endl;//outputs the input country and the converted celcius to new file
	}

	inFS.close();//closes file
	outFS.close();//closes file

	return 0;
}