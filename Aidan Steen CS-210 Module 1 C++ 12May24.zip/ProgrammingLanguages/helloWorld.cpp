#include <iostream>
using namespace std;

//Aidan Steen, 01May24

int main() {

	cout << "Hello World!" << endl;

	return 0;

}