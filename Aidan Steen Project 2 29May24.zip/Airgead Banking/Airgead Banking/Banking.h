#pragma once
#ifndef BANKING_H
#define BANKING_H

/*
Aidan Steen
CS-210
05/29/2024
*/

class Banking {
	//Setters and Getters
public:
	void SetInitialInvestment(double t_initialInvestment);
	double GetInitialInvestment() const;

	void SetMonthlyDeposit(double t_monthlyDeposit);
	double GetMonthlyDeposit() const;

	void SetAnnualInterest(double t_annualInterest);
	double GetAnnualInterest() const;

	void SetYears(double t_years);
	double GetYears() const;

	double calcBalanceWithoutMonthlyDeposit(double t_initialInvestment, 
		double t_annualInterest, double t_years);

	double balanceWithMonthlyDeposit(double t_initialInvestment, 
		double t_monthlyDeposit, double t_annualInterest, double t_years);


private:
	double m_initialInvestment;
	double m_totalAmount;
	double m_interestAmount;
	double m_yearlyTotalInterest;
	double m_monthlyDeposit;
	double m_years;
};

#endif
