/*
Aidan Steen
CS 210
6/22/2024
*/

#include <iostream>
#include <fstream>
#include <string>
#include <map>

using namespace std;

class ItemTracker {
private:
    map<string, int> itemFrequency;
    string dataFilePath;

public:
    ItemTracker() {
        dataFilePath = "frequency.dat"; //Names the output file
    }

    void processInputFile(const string& filePath) {
        ifstream inFS(filePath);
        string item;

        //if and else used to check if file can be opened or exists.
        if (inFS.is_open()) {
            while (getline(inFS, item)) {
                itemFrequency[item]++; //increments the item each time it is counted.
            }
            inFS.close(); //once file reaches end, closes file.
        }
        else {
            cout << "Error: Unable to open file " << filePath << endl;
        }
    }

    void saveToFile() {
        ofstream outFS(dataFilePath); //uses output data file stream to what is designated by dataFilePath which is "frequency.dat"

        if (outFS.is_open()) {
            for (const auto& pair : itemFrequency) {
                outFS << pair.first << " " << pair.second << endl; //outputs to format EX: "Yams 5"
            }
            outFS.close();
            cout << "Data saved to " << dataFilePath << endl; //once closed, lets user know that the data is saved.
        }
        else {
            cout << "Error: Unable to create output file " << dataFilePath << endl;
        }
    }

    void printItemFrequency() {
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " " << pair.second << endl; //formatted "Yams 5"
        }
    }

    void printHistogram() {
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " "; //lists the item "Yams "
            for (int i = 0; i < pair.second; i++) { //adds a * for everytime an item is counted EX: (Yams *****)
                cout << "*";
            }
            cout << endl;
        }
    }
    
    void itemLookup() {
        string userInput;

        cout << "Enter the item to look up: ";
                cin.ignore();
                getline(cin, userInput);
                cout << "\nFrequency of " << userInput << ": " << itemFrequency[userInput] << endl;
    }

    void run() {

        int choice;

        do {
            cout << "\nMenu Options:" << endl;
            cout << "1. Look up item frequency" << endl;
            cout << "2. Print item frequency list" << endl;
            cout << "3. Print item frequency histogram" << endl;
            cout << "4. Exit" << endl;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice) { //uses cases to pick the menu option
                //Each case calls a different function
            case 1:
                itemLookup();
                break;
            case 2:
                printItemFrequency();
                break;
            case 3:
                printHistogram();
                break;
            case 4:
                saveToFile();
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
            }
        } while (choice != 4);
    }
};

int main() {
    string inFS = "GroceryList.txt"; //"GroceryList.txt" is the name of the file to be opened for this program.
    ItemTracker tracker; //uses the ItemTracker class
    tracker.processInputFile(inFS);
    tracker.run();

    return 0;
}