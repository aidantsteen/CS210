#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <stdexcept>
#include "Banking.h"

/*
Aidan Steen
CS-210
05/29/2024
*/

using namespace std;
//Function that prints menu and allows user to enter data for calculations.
void PrintMenu(Banking& myInvestment, double& initialInvestment, 
	double& monthlyDeposit, double& annualInterest, double& years) {
	cout << std::string(34, '*') << endl;
	cout << "********** Data Input ************" << endl;
	cout << "Initial Investment Amount: $";
	cin >> initialInvestment;
	myInvestment.SetInitialInvestment(initialInvestment);
	cout << endl;
	while (initialInvestment < 0) {//While loops check that value is positive.
		cout << "Invalid Input. Please enter a value that is greater than 0." << endl;
		cout << "Initial Investment Amount: $";
		cin >> initialInvestment;
		myInvestment.SetInitialInvestment(initialInvestment);
	}
	cout << "Monthly Deposit: $";
	cin >> monthlyDeposit;
	myInvestment.SetMonthlyDeposit(monthlyDeposit);
	cout << endl;
	while (monthlyDeposit < 0) {//While loops check that value is positive.
		cout << "Invalid Input. Please enter a value that is greater than 0." << endl;
		cout << "Monthly Deposit: $";
		cin >> monthlyDeposit;
		myInvestment.SetMonthlyDeposit(monthlyDeposit);
	}
	cout << "Annual Interest Rate: %";
	cin >> annualInterest;
	myInvestment.SetAnnualInterest(annualInterest);
	cout << endl;
	while (annualInterest < 0) {//While loops check that value is positive.
		cout << "Invalid Input. Please enter a value that is greater than 0." << endl;
		cout << "Annual Interest Rate: %";
		cin >> annualInterest;
		myInvestment.SetAnnualInterest(annualInterest);
	}
	cout << "Number of years: ";
	cin >> years;
	myInvestment.SetYears(years);
	while (years < 0) {//While loops check that value is positive.
		cout << "Invalid Input. Please enter a value that is greater than 0." << endl;
		cout << "Number of years: ";
		cin >> years;
		myInvestment.SetYears(years);
	}
}

Banking myInvestment;
double initialInvestment;
double monthlyDeposit;
double annualInterest;
double years;
char input;

int main() {

	while (input != 'q') { //while loop checks user input. If input is 'q', program quits.
		PrintMenu(myInvestment, initialInvestment, monthlyDeposit, annualInterest, years);

		myInvestment.calcBalanceWithoutMonthlyDeposit(myInvestment.GetInitialInvestment(),
			myInvestment.GetAnnualInterest(), myInvestment.GetYears());

		myInvestment.balanceWithMonthlyDeposit(myInvestment.GetInitialInvestment(),
			myInvestment.GetMonthlyDeposit(), myInvestment.GetAnnualInterest(),
			myInvestment.GetYears());
		cout << endl;
		cout << "Press 'q' to quit or any other input to calculate another investment." << endl;
		cin >> input;
	}

	return 0;
}

