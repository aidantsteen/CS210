package homework;

// Aidan Steen, 01May24

public class HelloWorld {

	public static void main(String[] args) {
		
		System.out.println("Hello, World!"); //Statement used to print to output

	}

}
