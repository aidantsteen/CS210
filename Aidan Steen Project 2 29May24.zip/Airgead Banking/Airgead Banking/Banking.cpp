
#include "Banking.h"
#include <iostream>
#include <iomanip>

/*
Aidan Steen
CS-210
05/29/2024
*/

using namespace std;

//Setters and Getters

void Banking::SetInitialInvestment(double t_initialInvestment) {
	m_initialInvestment = t_initialInvestment;
	m_totalAmount = t_initialInvestment;
}
double Banking::GetInitialInvestment() const
{
	return m_totalAmount;
}
void Banking::SetMonthlyDeposit(double t_monthlyDeposit) {
	m_monthlyDeposit = t_monthlyDeposit;
}
double Banking::GetMonthlyDeposit() const {
	return m_monthlyDeposit;
}
void Banking::SetAnnualInterest(double t_annualInterest) {
	m_yearlyTotalInterest = t_annualInterest;
}
double Banking::GetAnnualInterest() const {
	return m_yearlyTotalInterest;
}
void Banking::SetYears(double t_years) {
	m_years = t_years;
}
double Banking::GetYears() const {
	return m_years;
}
double Banking::calcBalanceWithoutMonthlyDeposit(double t_initialInvestment, 
	double t_annualInterest, double t_years) {
	m_initialInvestment = t_initialInvestment;
	m_totalAmount = t_initialInvestment;

	//Table Header
	cout << endl << "     Balance and Interest Without Additional Monthly Deposits" << endl;
	cout << std::string(66, '=') << endl;
	cout << "Year          Year End Balance          Year End Earned Interest" << endl;
	cout << std::string(66, '-') << endl;

	//For loop takes the initial investment and does the interest
	//calculations based on the number of years.
	for (int i = 0; i < t_years; i++) {
		m_interestAmount = m_totalAmount * (t_annualInterest / 100);
		m_totalAmount = m_totalAmount + m_interestAmount;
		//Formatting and printing of each line calculation
		cout << " " << left << setw(5) << (i + 1) << "\t\t$" << fixed << setprecision(2) << 
			m_totalAmount << "\t\t\t\t$" << m_interestAmount << endl;
	}
	m_totalAmount = m_initialInvestment; //Resets value to initial investment to be
	//reused for second calculation.

	return m_totalAmount;
}

double Banking::balanceWithMonthlyDeposit(double t_initialInvestment, 
	double t_monthlyDeposit, double t_annualInterest, double t_years) {
	m_totalAmount = t_initialInvestment;

	//Table Header
	cout << endl << "     Balance and Interest With Additional Monthly Deposits" << endl;
	cout << std::string(66, '=') << endl;
	cout << "Year          Year End Balance          Year End Earned Interest" << endl;
	cout << std::string(66, '-') << endl;

	//For loop takes the initial investment and does the interest
	//calculations based on the number of years.
	for (int i = 0; i < t_years; i++) {
		m_yearlyTotalInterest = 0;

		for (int j = 0; j < 12; j++) {
			m_interestAmount = (m_totalAmount + t_monthlyDeposit) * ((t_annualInterest / 100.00) / 12.00);
			m_yearlyTotalInterest = m_yearlyTotalInterest + m_interestAmount;
			m_totalAmount = m_totalAmount + t_monthlyDeposit + m_interestAmount;
		}
		//Formatting and printing of each line calculation
		cout << " " << left << setw(5) << (i + 1) << "\t\t$" << fixed << setprecision(2) << 
			m_totalAmount << "\t\t\t\t$" << m_yearlyTotalInterest << endl;
	}

	return m_totalAmount;
}